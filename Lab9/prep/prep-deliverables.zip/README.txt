Step 1 is answered in Lab9_prep.c in the form of comments (as instructed by Lab9.doc)
Step 2 can be found in Therm12.xls
Step 3 can be found in Lab9.sch
Step 4 are the c files