void enableSpeaker(int enable);
