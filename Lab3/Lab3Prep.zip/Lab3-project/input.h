#include <stdint.h>
void input_init(void);
uint32_t getInput(void);
