#include <stdint.h>
void lcd_init(void);
void drawClock(void);
void drawLine(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t color);
