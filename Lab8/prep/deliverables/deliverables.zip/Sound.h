void Sound_Init(void);
void play_BGM(void);
void play_Explosion(void);
