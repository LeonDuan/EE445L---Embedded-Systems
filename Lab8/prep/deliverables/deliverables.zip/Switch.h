void Switches_Init(void);
uint32_t Switch0_Input(void);
uint32_t Switch1_Input(void);
uint32_t Switch2_Input(void);
uint32_t Switch3_Input(void);