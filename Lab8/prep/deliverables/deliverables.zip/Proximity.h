void Proximity_Init(void);
uint32_t get_Proximity(void);