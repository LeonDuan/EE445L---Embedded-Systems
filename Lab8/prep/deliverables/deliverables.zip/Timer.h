void Timer0_Init(void(*task)(void), uint32_t period);
void Timer1_Init(void(*task)(void), uint32_t period);
void Timer2_Init(void(*task)(void), uint32_t period);
void Timer3_Init(void(*task)(void), uint32_t period);
