// this function updates the entire screen (with information updated by the Game module)
void update_Screen(void);