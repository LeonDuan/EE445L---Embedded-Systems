void Switch_Init(void(*touchtask_PE1)(void), void(*touchtask_PE2)(void));
