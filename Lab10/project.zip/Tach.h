void Tach_Init(void);
uint32_t Tach_Read(void);
uint32_t Tach_Speed(void);
