void drawNext(uint32_t y, uint16_t color, int addX);
void ST7735_XYplotInit(int32_t minX, int32_t maxX, int32_t minY, int32_t maxY);
